var Name = document.getElementById("Name")
var email = document.getElementById("email")
var password = document.getElementById("password")
var mobile = document.getElementById("mobile number")
var date = document.getElementById("date")

var Message = document.getElementById("message")


let currentUser = () => {
  firebase.auth().onAuthStateChanged((user) => {

    if (user) {
     console.log(
      user,{
      displayName:Name,
      email : email,
       emailVerified : user.emailVerified,
       uid : user.uid,
      mobile :"03328278412"

      
     })
    } else {
      console.log("none");
    }
  });
};
let signUp = () => {
  Message.style.display = "block"
  Message.style.color = "red"
if (Name.value === "") {
  Message.innerHTML = "Name required"
  Name.focus()
  Name.style.backgroundColor="red"

  setTimeout(function () {
    Message.style.display = "none"
    Name.style.backgroundColor=""
    
  }, 1000);
}
else if (email.value === "") {
  Message.innerHTML = "Email required"
  email.focus()
  email.style.backgroundColor="red"

  setTimeout(function () {
    Message.style.display = "none"
  email.style.backgroundColor=""

  }, 1000);
} else if (password.value === "") {
  Message.innerHTML = "Password required"
  password.focus()
  password.style.backgroundColor="red"


  setTimeout(function () {
    Message.style.display = "none"
  password.style.backgroundColor=""

  }, 1000);
} else if (password.value.length < 8) {
  Message.innerHTML = " type min 8 letter  password "
  password.focus()
  password.style.backgroundColor="red"
  
  setTimeout(function () {
    Message.style.display = "none"
  password.style.backgroundColor=""

  }, 1000);
} else if (mobile.value === "") {
  // alert("mobile number requried")
  Message.innerHTML = "Mobile number required"
  mobile.focus()
  mobile.style.backgroundColor="red"
  
  setTimeout(function () {
    Message.style.display = "none"
  mobile.style.backgroundColor=""

  }, 1000);
} else if (mobile.value.length !== 11) {
  mobile.focus()
  mobile.style.backgroundColor="red"

  Message.innerHTML = " type correct Mobile number "
  setTimeout(function () {
    Message.style.display = "none"
    mobile.style.backgroundColor=""

  }, 1000);
} else if (date.value === "") {
  // alert("date requried")
  Message.innerHTML = "Date required"
  date.focus()
  date.style.backgroundColor="red"
  
  setTimeout(function () {
    Message.style.display = "none"
    date.style.backgroundColor=""

  }, 1000);
} else {
  firebase.auth().createUserWithEmailAndPassword(email.value, password.value).then((userCredential) => {
    console.log("successfully Signed Up", userCredential);})
    firebase.database().ref('users/').push({
      name: Name.value,
      email: email.value,
      password: password.value,
      mobile: mobile.value,
      date: date.value,
    });
  console.log(Name.value)
  console.log(email.value)
  console.log(password.value)
  console.log(mobile.value)
  console.log(date.value)
  Message.style.display = "block"
  Message.innerHTML = "success"
  Message.style.color = "green"
  setTimeout(function () {
    Message.style.display = "none"
  //  mobile.style.backgroundColor="none"

    Name.value = ""
    email.value = ""
    password.value = ""
    mobile.value = ""
    date.value = ""
  }, 1000);

}
  
};




var provider = new firebase.auth.GoogleAuthProvider();
let googlesignup = () => {
        firebase.auth().signInWithPopup(provider).then((result) => {
         console.log(result)

        }).catch((error) => {
          console.log("error", error);
        });
   
}

let signOut = () => {
  firebase.auth().signOut()
    .then((userCredential) => {
      console.log("Signed out");
      window.location.assign("signin.html");
    })
    .catch((error) => {
      console.log("error", error);
    });
};

let verifyemail = () => {
  Message.style.display = "block"
  
  Message.style.color = "green"
  firebase.auth().currentUser.sendEmailVerification().then(() => {
   
    Message.innerHTML = " Email verification sent!"

  

  });
 setTimeout(() => {
   Message.style.display = "none"
  //  verify.value = ""

   // window.location.assign("signin.html");
 }, 2000);
}



let forgotpasswordemail = document.getElementById("forgotpasswordemail")
var Message = document.getElementById("message");


const forgotpassword =()=>{
  Message.style.color = "green"
  Message.style.display = "block"
   firebase.auth().sendPasswordResetEmail(forgotpasswordemail.value).then(() => {
     Message.innerHTML = " successfully sent"
    console.log("ssss")
     setTimeout(() => {
       Message.style.display = "none"
       forgotpasswordemail.value=""
      //  window.location.assign("signin.html");
     }, 1000);
   })
   .catch((error) => {
   Message.innerHTML = "please enter email "
   Message.style.display = "block"
  Message.style.color = "red"

   setTimeout(() => {
     Message.style.display = "none"
     Message.innerHTML = " "
 
   }, 1000);
 
   });
}


const backtologin = () => {
   
  window.location.assign("signin.html");
};
let verifylater = () => {
   
  window.location.assign("home.html");
};


// const user = firebase.auth().currentUser;


firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    console.log(user);
  } else {
    console.log("none");
  }
});







const presentUser = () => {
    // let user = firebase.auth().currentUser;
    console.log("current user",  firebase.auth().currentUser)
}

// update user data
const UpdateUser = () => {
    const user = firebase.auth().currentUser;

    user.updateProfile({
        displayName: "iHunar Academy",
        photoURL: "https://example.com/jane-q-user/profile.jpg"
    }).then(() => {
        // Update successful
        console.log("Update successful")
    }).catch((error) => {
        // An error occurred
        console.log("error", error)
    });
}

// const user = firebase.auth().currentuser;



const profile = () => {
  // const user = firebase.auth().currentUser;
  if (user) {
    displayName : "darshankumar";
    email : "darshkumar@gmail.com";
     emailVerified: user.emailVerified;
     uid: user.uid;
  }
}


let verify = document.getElementById("verify");
var Message = document.getElementById("message");










