let menuicn = document.querySelector(".menuicn");
let nav = document.querySelector(".navcontainer");

menuicn.addEventListener("click", () => {
  nav.classList.toggle("navclose");
})

let NoData = document.getElementById("no-data")
let p1 = document.getElementById("p1")
let p2 = document.getElementById("p2")
let p3 = document.getElementById("p3")
let p4 = document.getElementById("p4")
 
onload = function () {


  let NoData = document.getElementById("no-data")

  firebase.firestore().collection("todos").onSnapshot((doc) => {
    ul.innerHTML = ""
    loader.style.display = "none";
    NoData.style.display = "none";

    if (doc.size === 0) {
      NoData.style.display = "block"
      console.log("none")
      NoData.innerHTML = "No data"
    } else {
      ul.style.display = "block"
      doc.forEach((docRes) => {
        let data = docRes;
        let p1 = document.getElementById("p1")
        let p2 = document.getElementById("p2")
        let p3 = document.getElementById("p3")
        let p4 = document.getElementById("p4")
        p1.innerHTML = doc.size
        p2.innerHTML = doc.size
        p3.innerHTML = doc.size
        p4.innerHTML = doc.size
       
        // console.log("data", data.data());
        let li = document.createElement("li");
        // li.setAttribute("class")
        ul.appendChild(li);
        li.innerHTML = data.data().name

        let ul2 = document.getElementById("ul2")
        let li2 = document.createElement("li");
        ul2.appendChild(li2);
        li2.innerHTML = data.data().email
        let ul3 = document.getElementById("ul3")
        let li3 = document.createElement("li");
        ul3.appendChild(li3);
        li3.innerHTML = data.data().mobile
        let ul4 = document.getElementById("ul4")
        let li4 = document.createElement("li");
        ul4.appendChild(li4);
        li4.innerHTML = data.data().date
        let ul5 = document.getElementById("ul5")
        let li5 = document.createElement("li");
        ul5.appendChild(li5);
        li5.innerHTML = data.data().courses

      })
    }
  })
  // var docRef = firebase.firestore().collection("todos").doc();

  // docRef.get().then((doc) => {
  //   if (doc.exists) {
  //     console.log("Document data:", doc.data());
  //   } else {
  //     // doc.data() will be undefined in this case
  //     console.log("No such document!");
  //   }
  // }).catch((error) => {
  //   console.log("Error getting document:", error);
  // });
}




window.onload = function () {


  let NoData = document.getElementById("no-data")

  firebase.firestore().collection("todos").onSnapshot((doc) => {
    ul.innerHTML = ""
    loader.style.display = "none";
    NoData.style.display = "none";
    if (doc.size === 0) {
      NoData.style.display = "block"
      console.log("none")
      NoData.innerHTML = "No data"
    } else {
      ul.style.display = "block"
      doc.forEach((docRes) => {
        let data = docRes;
        let p1 = document.getElementById("p1")
        let p2 = document.getElementById("p2")
        let p3 = document.getElementById("p3")
        let p4 = document.getElementById("p4")
        p1.innerHTML = doc.size
        p2.innerHTML = doc.size
        p3.innerHTML = doc.size
        p4.innerHTML = doc.size
       
        // console.log("data", data.data());
        let li = document.createElement("li");
        // li.setAttribute("class")
        ul.appendChild(li);
        li.innerHTML = data.data().name

        let ul2 = document.getElementById("ul2")
        let li2 = document.createElement("li");
        ul2.appendChild(li2);
        li2.innerHTML = data.data().email
        let ul3 = document.getElementById("ul3")
        let li3 = document.createElement("li");
        ul3.appendChild(li3);
        li3.innerHTML = data.data().mobile
        let ul4 = document.getElementById("ul4")
        let li4 = document.createElement("li");
        ul4.appendChild(li4);
        li4.innerHTML = data.data().date
        let ul5 = document.getElementById("ul5")
        let li5 = document.createElement("li");
        ul5.appendChild(li5);
        li5.innerHTML = data.data().courses

      })
    }
  })

  firebase.firestore().collection("todos").where("courses", "==", "wordpress")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p1.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


    firebase.firestore().collection("todos").where("courses", "==", "web-development")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p2.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


    firebase.firestore().collection("todos").where("courses", "==", "social-media-marketing")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p3.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    firebase.firestore().collection("todos").where("courses", "==", "app-development")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p4.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


    firebase.firestore().collection("todos").where("courses", "==", "video-editing")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p5.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    firebase.firestore().collection("todos").where("courses", "==", "yutube-mastery")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p6.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    firebase.firestore().collection("todos").where("courses", "==", "CS")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p7.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    firebase.firestore().collection("todos").where("courses", "==", "IT")
    .get()
    .then((querySnapshot) => {
      console.log("wordpress:- " , querySnapshot.size);
      p8.innerHTML= querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
  // var docRef = firebase.firestore().collection("todos").doc();

  // docRef.get().then((doc) => {
  //   if (doc.exists) {
  //     console.log("Document data:", doc.data());
  //   } else {
  //     // doc.data() will be undefined in this case
  //     console.log("No such document!");
  //   }
  // }).catch((error) => {
  //   console.log("Error getting document:", error);
  // });
}

const d=()=>{
  firebase.firestore().collection("todos").get().then((querySnapshot) => {
    
    ul.innerHTML = ""
    loader.style.display = "none";
    NoData.style.display = "none";

    if (querySnapshot.size === 0) {
      NoData.style.display = "block"
      console.log("none")
      NoData.innerHTML = "No data"
    } else {
      ul.style.display = "block"
      querySnapshot.forEach((docRes) => {
        let data = docRes;
        
       
        // console.log("data", data.data());
        let li = document.createElement("li");
        // li.setAttribute("class")
        ul.appendChild(li);
        li.innerHTML = data.data().name

        let ul2 = document.getElementById("ul2")
        let li2 = document.createElement("li");
        ul2.appendChild(li2);
        li2.innerHTML = data.data().email
        let ul3 = document.getElementById("ul3")
        let li3 = document.createElement("li");
        ul3.appendChild(li3);
        li3.innerHTML = data.data().mobile
        let ul4 = document.getElementById("ul4")
        let li4 = document.createElement("li");
        ul4.appendChild(li4);
        li4.innerHTML = data.data().date
        let ul5 = document.getElementById("ul5")
        let li5 = document.createElement("li");
        ul5.appendChild(li5);
        li5.innerHTML = data.data().courses

      })
    }
});
}

var item=document.getElementsByClassName("item1")
const viewall=()=>{
  // firebase.auth().onAuthStateChanged((user) => {
      
  //   if (user) {
  //   //  window.location.assign("home.html")

  //    console.log( user.email)
  //   //  p1.innerHTML= user

  //   } else {
  //     console.log("none");
  //   //  p1.innerHTML= "none"
  //     window.location.assign("./../pages/signin.html");

  //   }
  // });
  
  
}
