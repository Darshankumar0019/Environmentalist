
// let Name=document.getElementById("name")
let email = document.getElementById("email");
let password = document.getElementById("password");

var Message = document.getElementById("message")


let signIn = () => {
  Message.style.display = "block"
  Message.style.color = "red"
 if (email.value === "") {
  Message.innerHTML = "Email required"
  email.focus()
  email.style.backgroundColor="red"

  setTimeout(function () {
    Message.style.display = "none"
  email.style.backgroundColor=""

  }, 1000);
} else if (password.value === "") {
  Message.innerHTML = "Password required"
  password.focus()
  password.style.backgroundColor="red"


  setTimeout(function () {
    Message.style.display = "none"
  password.style.backgroundColor=""

  }, 1000);

} else {
  console.log(email.value)
  console.log(password.value)
  Message.style.display = "block"
  Message.innerHTML = "success"
  Message.style.color = "green"
  setTimeout(function () {
    Message.style.display = "none"
  //  mobile.style.backgroundColor="none"

    email.value = ""
    password.value = ""
  }, 1000);
   
  firebase.auth().signInWithEmailAndPassword(email.value, password.value).then((userCredential) => {
        console.log("successfully Login", userCredential);
        var user = userCredential.user;
        if(signIn = true){
          if (user.emailVerified === true) {
            window.location.assign("home.html");
          } else {
            window.location.assign("verifyemailaddress.html");
          }
        }else{
          window.location.assign("signin.html");
        }
       
      })
      .catch((error) => {
        console.log("error", error);
        alert("something wrong ");
      });
 
  };

  



}

  var provider = new firebase.auth.GoogleAuthProvider();
let googlesignin = () => {
        firebase.auth().signInWithPopup(provider).then((result) => {
         console.log(result)

        }).catch((error) => {

          console.log("error", error);


        });
   
      }

      let currentUser = () => {
        firebase.auth().onAuthStateChanged((user) => {
      
          if (user) {
          //  window.location.assign("home.html")

           console.log( user)
          } else {
            console.log("none");
          }
        });
      };
      let present = () => {
        firebase.auth().onAuthStateChanged((user) => {
      
          if (user) {
           console.log( user)

           window.location.assign("home.html")

          } else {
            console.log("none");
          }
        });
      };
       function updateCurrentUser(){
        const user = firebase.auth().currentUser;
        user.updateProfile({
          
          displayName: "iHunar Academy",
          photoURL: "https://example.com/jane-q-user/profile.jpg",
      }).then(() => {
          // Update successful
          console.log("Update successful")
          // document.write ("success") 
         
      }).catch((error) => {
          // An error occurred
          console.log("error", error)
      });
       }
    
      let signOut = () => {
        firebase.auth().signOut()
          .then((userCredential) => {
            console.log("Signed out");
            window.location.assign("signin.html");
          })
          .catch((error) => {
            console.log("error", error);
          });
      };