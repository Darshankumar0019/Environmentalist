

var Name = document.getElementById("Name")
var email = document.getElementById("email")
var password = document.getElementById("password")
var mobile = document.getElementById("mobile number")
var date = document.getElementById("date")
var courses = document.getElementById("courses")

var Message = document.getElementById("message")

let Add = () => {
    Message.style.display = "block"
    Message.style.color = "red"
  if (Name.value === "") {
    Message.innerHTML = "Name required"
    Name.focus()
    Name.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
      Name.style.backgroundColor=""
  
    }, 1000);
  }
  else if (email.value === "") {
    Message.innerHTML = "Email required"
    email.focus()
    email.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
    email.style.backgroundColor=""
  
    }, 1000);
  } else if (password.value === "") {
    Message.innerHTML = "Password required"
    password.focus()
    password.style.backgroundColor="red"
  
  
    setTimeout(function () {
      Message.style.display = "none"
    password.style.backgroundColor=""
  
    }, 1000);
  } else if (password.value.length < 8) {
    Message.innerHTML = " type min 8 letter  password "
    password.focus()
    password.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
    password.style.backgroundColor=""
  
    }, 1000);
  } else if (mobile.value === "") {
    // alert("mobile number requried")
    Message.innerHTML = "Mobile number required"
    mobile.focus()
    mobile.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
    mobile.style.backgroundColor=""
  
    }, 1000);
  } else if (mobile.value.length !== 11) {
    mobile.focus()
    mobile.style.backgroundColor="red"
  
    Message.innerHTML = " type correct Mobile number "
    setTimeout(function () {
      Message.style.display = "none"
      mobile.style.backgroundColor=""
  
    }, 1000);
  } else if (date.value === "") {
    // alert("date requried")
    Message.innerHTML = "Date required"
    date.focus()
    date.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
      date.style.backgroundColor=""
  
    }, 1000);
  } else if (courses.value === "") {
    // alert("date requried")
    Message.innerHTML = " select courses"
    courses.focus()
    courses.style.backgroundColor="red"
  
    setTimeout(function () {
      Message.style.display = "none"
      courses.style.backgroundColor=""
  
    }, 1000);
  } else {
    firebase.auth().createUserWithEmailAndPassword(email.value, password.value).then((userCredential) => {
      console.log("successfully Signed Up", userCredential);})
      firebase.firestore().collection("todos/").add({
        name:Name.value,
        email: email.value,
        date:date.value,
        mobile:mobile.value,
        courses:courses.value,
    }).then((res) => {
        console.log("Document successfully written!", res);
        message.innerHTML = "Document successfully written!";
        message.style.color = "green";
        
        // firebase.firestore().collection("todos/").doc(res.id).update({
        //     id: res.id
        // })
        setTimeout(() => {
            message.style.display = "none"
        }, 2000);
    })
        .catch((error) => {
            console.error("Error writing document: ", error);
        });
      firebase.database().ref('users/').push({
        name: Name.value,
        email: email.value,
        password: password.value,
        mobile: mobile.value,
        courses:courses.value,
        date: date.value,
      });
     
  
    console.log(Name.value)
    console.log(email.value)
    console.log(password.value)
    console.log(mobile.value)
    console.log(date.value)
    console.log(courses.value)
    Message.style.display = "block"
    Message.innerHTML = "success"
    Message.style.color = "green"
    setTimeout(function () {
      Message.style.display = "none"
    //  mobile.style.backgroundColor="none"
  
      Name.value = ""
      email.value = ""
      password.value = ""
      mobile.value = ""
      date.value = ""
      courses.value = ""
    }, 1000);
  
  }
  
  };
  
  let verifylater = () => {
   window.location.assign("home.html")
  }
  
  
  var provider = new firebase.auth.GoogleAuthProvider();
  let googlesignup = () => {
          firebase.auth().signInWithPopup(provider).then((result) => {
           console.log(result)
  
          }).catch((error) => {
            console.log("error", error);
          });
  
  }

let loader = document.getElementById("loader")
let ul = document.getElementById("ul")
// get data
const addd = () => {
  firebase.database().ref("todos/").on("value", (dataRes) => {
    console.log("dataRes", dataRes.ref
    )
    ul.innerHTML = ""
    loader.style.display = "none";
    ul.style.display = "block"
    dataRes.forEach((res) => {
      let data = res.val()
      console.log("Data >>>>>>", data)
      let li = document.createElement("li");
      ul.appendChild(li);
      li.innerHTML =  res.val().name;
    
    })
  })
}

let input = document.getElementById("input");
let message = document.getElementById("message")
let AddData = () => {
  loader.style.display = "none"
  message.style.display = "block"
  if (input.value === "") {
    message.innerHTML = "Type something...";
    message.style.color = "red";
    setTimeout(() => {
      message.style.display = "none"
    }, 2000);
  } else {

    // firebase.firestore().collection("todos/").doc("user2").set({
    //     value: input.value
    // }).then(() => {
    //     console.log("Document successfully written!");
    //     message.innerHTML = "Document successfully written!";
    //     message.style.color = "green";
    //     input.value = ""
    //     setTimeout(() => {
    //         message.style.display = "none"
    //     }, 2000);
    // })
    //     .catch((error) => {
    //         console.error("Error writing document: ", error);
    //     });


    firebase.firestore().collection("todos/").add({
      // value: input.value,
      name: "Tokyo",
      country: "Japan"
    }).then((res) => {
      console.log("Document successfully written!", res);
      message.innerHTML = "Document successfully written!";
      message.style.color = "green";
      input.value = "";
      firebase.firestore().collection("todos/").doc(res.id).update({
        id: res.id
      })
      setTimeout(() => {
        message.style.display = "none"
      }, 2000);
    })
      .catch((error) => {
        console.error("Error writing document: ", error);
      });

    // firebase.database().ref("todos/" ).push(
    //     {    
    //     }, (error) => {
    //         if (error) {
    //             // The write failed...
    //         } else {
    //             // Data saved successfully!
    //             message.innerHTML = "Data saved successfully!";
    //             message.style.color = "green";
    //             input.value = ""
    //             setTimeout(() => {
    //                 message.style.display = "none"
    //             }, 2000);
    //         }
    //     }
    // ).then((res) => {
    //     console.log(res);
    //     firebase.database().ref("todos/" + res.key).update({
    //         id: res.key
    //     })
    // })
  }
}

// let loader = document.getElementById("loader")
// let ul = document.getElementById("ul")
// get data
// firebase.database().ref("todos/").on("value", (dataRes) => {
//     console.log("dataRes",dataRes.ref
//     )
//     ul.innerHTML = ""
//     loader.style.display = "none";
//     ul.style.display = "block"
//     dataRes.forEach((res) => {
//         let data = res.val()
//         console.log("Data >>>>>>", data)
//         let li = document.createElement("li");
//         ul.appendChild(li);
//         li.innerHTML = data.value;
//         let editButton = document.createElement("button");
//         li.appendChild(editButton);
//         editButton.innerHTML = "Edit";
//         let deleteButton = document.createElement("button");
//         li.appendChild(deleteButton);
//         deleteButton.innerHTML = "Delete";
//         // edit funciton
//         editButton.addEventListener("click", () => {
//             var pro = prompt("", data.value)
//             firebase.database().ref("todos/" + data.id).update({
//                 value: pro
//             })
//         })
//         // delete funciton
//         deleteButton.addEventListener("click", () => {
//             firebase.database().ref("todos/" + data.id).remove()
//         })
//     })
// })




// firestore database
// all 10000
// pending  2000
// approve 7000
// reject 1000
// date 10/05/2023 - 20/06/2023

//

// var users = [
//     {
//         name: "ABc",
//         country: "Pakistan"
//     },
//     {
//         name: "ABc",
//         country: "India"
//     }
// ]

// country === "Pakistan"

// 50pkr 500pk




// firebase.firestore().collection("todos").doc("EY0kdvuZYVuHwU3nLdHK").get().then((doc) => {
//     loader.style.display = "none"
//     if (doc.exists) {
//         console.log("Document data:", doc.data());
//     } else {
//         // doc.data() will be undefined in this case
//         console.log("No such document!");
//     }
// }).catch((error) => {
//     console.log("Error getting document:", error);
// });


let NoData = document.getElementById("no-data")

// const add=()=>{
//   firebase.firestore().collection("todos").get().then((doc) => {
//     loader.style.display = "none";

//     if (doc.size === 0) {
//         NoData.style.display = "block"
//     } else {
//         ul.style.display = "block"
//         doc.forEach((docRes) => {
//             let data = docRes;
//             console.log("data",  data.data().value);
//             let li = document.createElement("li");
//             ul.appendChild(li);
//             li.innerHTML = data.data().value
//         })

//     }
// }).catch((error) => {
//     console.log("Error getting document:", error);
// });

//